module.exports = function(){
    var express = require('express');
    var router = express.Router();

    function getFood(res, mysql, context, complete){
        mysql.pool.query("SELECT FoodID AS fid, FoodName AS fname,FoodDesc AS dname , FoodPrice AS price FROM food", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.food  = results;
            complete();
        });
    }
    
    router.get('/', function(req, res){
        var callbackCount = 0;
        var context = {};
        context.jsscripts = ["deleteperson.js"];
        var mysql = req.app.get('mysql');
        getFood(res, mysql, context,complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('add_food', context);
            }
        }
    });

    router.post('/', function(req, res){
        console.log(req.body.homeworld)
        console.log(req.body)
        var mysql = req.app.get('mysql');
        var sql = "INSERT INTO food (FoodName, FoodDesc,FoodPrice) VALUES (?,?,?)";
        var inserts = [req.body.fname, req.body.dname,req.body.price];
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                console.log(JSON.stringify(error))
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.redirect('/add_food');
            }
        });
    });


    return router;
}();