var mysql = require('mysql');
var pool = mysql.createPool({
  connectionLimit : 10,
  host            : 'classmysql.engr.oregonstate.edu',
  user            : 'cs340_yusim',
  password        : '0429',
  database        : 'cs340_yusim'
});
module.exports.pool = pool;
