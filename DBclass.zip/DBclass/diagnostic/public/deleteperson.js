  
function deletePerson(id){
  $.ajax({
      url: '/people/' + id,
      type: 'DELETE',
      success: function(result){
          window.location.reload(true);
      }
  })
};

function deleteFoodOrder(oid, fid){
$.ajax({
    url: '/order_food/oid/' + oid + '/food/' + fid,
    type: 'DELETE',
    success: function(result){
        if(result.responseText != undefined){
          alert(result.responseText)
        }
        else {
          window.location.reload(true)
        } 
    }
})
};