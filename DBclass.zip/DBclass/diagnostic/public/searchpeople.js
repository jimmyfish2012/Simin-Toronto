function searchPeopleByFirstName() {
    //get the first name 
    var cellphone_search  = document.getElementById('cellphone_input').value
    //construct the URL and redirect to it
    window.location = '/people/search/' + encodeURI(cellphone_search)
}
